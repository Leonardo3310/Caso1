package segundotest;

public class Buffersito {
    private final int capacidad;
    private boolean[] buffer;
    private int count = 0;

    public Buffersito(int capacidad) {
        this.capacidad = capacidad;
        this.buffer = new boolean[capacidad];
    }

    public synchronized void enviar(boolean estado) {
        while (count == capacidad) {
            try {
                wait(); // Espera pasiva si el buffer está lleno
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        buffer[count++] = estado;
        notifyAll(); // Notifica a los threads en espera que hay un nuevo estado
    }

    public synchronized boolean recibir() {
        while (count == 0) {
            try {
                wait(); // Espera semi-activa si el buffer está vacío
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        boolean estado = buffer[--count];
        notifyAll(); // Notifica a los threads en espera que hay espacio en el buffer
        return estado;
    }
}

