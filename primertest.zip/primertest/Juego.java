package primertest;
import primertest.*;
import java.util.concurrent.CyclicBarrier;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class Juego {
    private Celula[][] board;
    public static final int NUM_GENERATIONS = 10; // Este valor puede ser ajustado o ingresado por el usuario
    public static CyclicBarrier BARRIER;

    public Juego() {
    }

    public void loadInitialState(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            // Leer la primera línea para obtener el tamaño del tablero
            String firstLine = br.readLine();
            int size = Integer.parseInt(firstLine.trim());
    
            // Inicializar 'board' y 'BARRIER' aquí con el tamaño obtenido
            board = new Celula[size][size];
            BARRIER = new CyclicBarrier(size * size + 1); // Incluye todas las celdas más el hilo principal
    
            String line;
            int row = 0;
            while ((line = br.readLine()) != null && row < board.length) {
                String[] values = line.split(" ");
                for (int col = 0; col < values.length && col < board[row].length; col++) {
                    boolean alive = values[col].equals("true");
                    board[row][col] = new Celula(alive, row, col, board.length);
                }
                row++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    

    public void initializeNeighbors() {
        int[] dx = {-1, -1, -1, 0, 0, 1, 1, 1};
        int[] dy = {-1, 0, 1, -1, 1, -1, 0, 1};

        for (int row = 0; row < board.length; row++) {
            for (int col = 0; col < board[row].length; col++) {
                Buffersito[] neighborMailboxes = new Buffersito[8];
                int count = 0;
                for (int i = 0; i < 8; i++) {
                    int nx = row + dx[i];
                    int ny = col + dy[i];
                    if (nx >= 0 && nx < board.length && ny >= 0 && ny < board[nx].length) {
                        neighborMailboxes[count++] = board[nx][ny].obtenerBuffer();
                    }
                }
                board[row][col].setNeighborMailboxes(neighborMailboxes);
            }
        }
    }

    public void simulate() {
        ExecutorService executor = Executors.newFixedThreadPool(board.length * board.length);
        for (int row = 0; row < board.length; row++) {
            for (int col = 0; col < board[row].length; col++) {
                executor.execute(board[row][col]);
            }
        }
    
        // Esperar a que todas las generaciones se completen
        for (int i = 0; i < NUM_GENERATIONS; i++) {
            try {
                BARRIER.await();
                printBoard(); // Imprimir el estado del tablero después de cada generación
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    
        executor.shutdown();
        try {
            executor.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    

    public static void main(String[] args) {
        try {
            Juego game = new Juego(); // Juego ya no necesita el tamaño como argumento del constructor
            game.loadInitialState(args[0]);
            game.initializeNeighbors();
            game.simulate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    

    public void printBoard() {
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                //System.out.print(board[i][j].estaVivo());
                System.out.print(board[i][j].estaVivo() ? "■ " : "□ ");
            }
            System.out.println(); // Nueva línea al final de cada fila
        }
        System.out.println(); // Línea adicional para separar las generaciones
    }
    
}

