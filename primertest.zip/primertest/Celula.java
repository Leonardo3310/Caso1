package primertest;
import primertest.*;
import java.util.concurrent.BrokenBarrierException;

public class Celula implements Runnable {
    private boolean alive;
    private boolean nextAlive;
    private Buffersito[] neighborMailboxes;
    private Buffersito myMailbox;
    private final int row;
    private final int column;

    public Celula(boolean initialState, int row, int column, int mailboxCapacity) {
        this.alive = initialState;
        this.nextAlive = false;
        this.row = row;
        this.column = column;
        this.myMailbox = new Buffersito(mailboxCapacity);
        this.neighborMailboxes = new Buffersito[8]; // Cada celda tiene como máximo 8 vecinos
    }

    public void setNeighborMailboxes(Buffersito[] neighborMailboxes) {
        this.neighborMailboxes = neighborMailboxes;
    }

    public boolean estaVivo() {
        return alive;
    }

    public Buffersito obtenerBuffer() {
        return myMailbox;
    }

    @Override
    public void run() {
        try {
            // Ciclo de vida de la celda para cada generación
            for (int i = 0; i < Juego.NUM_GENERATIONS; i++) {
                int aliveNeighbors = 0;

                // Enviar el estado actual a todas las celdas vecinas
                for (Buffersito mailbox : neighborMailboxes) {
                    if (mailbox != null) mailbox.send(alive);
                }

                // Recibir el estado de las celdas vecinas y contar cuántas están vivas
                for (Buffersito mailbox : neighborMailboxes) {
                    if (mailbox != null && mailbox.receive()) {
                        aliveNeighbors++;
                    }
                }

                // Aplicar las reglas del Juego de la Vida para determinar el siguiente estado
                if (alive) {
                    // Muere por sobrepoblación o aislamiento
                    if (aliveNeighbors < 2 || aliveNeighbors > 3) nextAlive = false;
                    else nextAlive = true; // Sigue viva
                } else {
                    // Nace si tiene exactamente 3 vecinos vivos
                    if (aliveNeighbors == 3) nextAlive = true;
                }

                // Esperar a que todas las celdas calculen su siguiente estado
                // (Podría implementarse usando una barrera de sincronización como CyclicBarrier)
                Juego.BARRIER.await();

                // Actualizar el estado para la siguiente generación
                alive = nextAlive;

                // Opcional: Mostrar el estado actual de la celda (para depuración o visualización)
            }
        } catch (InterruptedException | BrokenBarrierException e) {
            e.printStackTrace();
        }
    }


    // Métodos adicionales para calcular el siguiente estado y actualizar el estado actual
}
