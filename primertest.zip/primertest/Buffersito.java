package primertest;
import primertest.*;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class Buffersito {
    private BlockingQueue<Boolean> queue;

    public Buffersito(int capacity) {
        this.queue = new LinkedBlockingQueue<>(capacity);
    }

    public void send(Boolean message) throws InterruptedException {
        queue.put(message); // Espera pasiva si el buzón está lleno
    }

    public Boolean receive() throws InterruptedException {
        return queue.take(); // Espera semi-activa para recibir mensajes
    }
}

